<?php
/**
 * @file    validators/range.php
 * @brief   range (number) validator
 **/
namespace depage\htmlform\validators;

/**
 * @brief default validator for range input elements
 **/
class range extends number {
}
